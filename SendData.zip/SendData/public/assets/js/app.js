const contactForm = document.querySelector('.submit-btn');
const username = document.getElementById('name');
const email = document.getElementById('email');
const subject = document.getElementById('subject');
const message = document.getElementById('message');

contactForm.addEventListener('click', (e) => {
    e.preventDefault();

    let formData = {
        username: username.value,
        email: email.value,
        subject: subject.value,
        message: message.value

    }

    let xhr = new XMLHttpRequest();
    xhr.open('POST','/');
    xhr.setRequestHeader('content-type','application/json');
    xhr.onload = function(){
        console.log(xhr.responseText);
        if(xhr.responseText == "success")
        {
            alert('email sent');

        }
        else{
            alert("something went wrong!!");
        }
    }

    xhr.send(JSON.stringify(formData));

})
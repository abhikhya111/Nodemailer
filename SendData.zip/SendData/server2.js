const hbs = require('nodemailer-express-handlebars')
const nodemailer = require('nodemailer')
const path = require('path')
const express = require('express');
const Email = require('email-templates');

const app = express();
// initialize nodemailer
app.use(express.static('public'));
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
})

app.post('/',(req,res) => {
    var mailOptions1 = {
        from: req.body.email, // sender address

        to: 'abhikhya.ashi@gmail.com',
        subject: `Message from ${req.body.email} : ${req.body.subject}`,
        template: 'email', // the name of the template file i.e email.handlebars
        text : req.body.message,
        context:{
            name: "Adebola", // replace {{name}} with Adebola
            company: 'My Company' // replace {{company}} with My Company
        }
    };

    transporter.sendMail(mailOptions1, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
    
});
})

app.use(express.json());

app.listen(3000, console.log('Server running on port 3000'));

var transporter = nodemailer.createTransport(
    {
        service: 'gmail',
        auth:{
            user: 'abhikhya.ashi@gmail.com',
            pass: 'ashi@3666'
        }
    }
);

// point to the template folder



var mailOptions2 = {
    from: 'abhikhya.ashi@gmail.com', // sender address
    to: 'abhikhya.ashi@gmail.com',
    subject: 'Welcome!',
    template: 'email', // the name of the template file i.e email.handlebars
    context:{
        name: "Adebola", // replace {{name}} with Adebola
        company: 'My Company' // replace {{company}} with My Company
    }
};
const transporter = nodemailer(mailOptions2, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
    
});
const email = new Email({
      transport: transporter,
      send: true,
      preview: false,
    });
// trigger the sending of the E-mail
// transporter.sendMail(mailOptions2, function(error, info){
//     if(error){
//         return console.log(error);
//     }
//     console.log('Message sent: ' + info.response);
// });
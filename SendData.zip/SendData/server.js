const express = require('express');
const app = express();
const nodemailer = require('nodemailer');
app.use(express.static('public'));
app.use(express.json());

app.get('/', (req,res) => {
    req.sendFile(__dirname + '/public/index.html')
})

app.post('/', (req,res) =>{
    const transporter = nodemailer.createTransport(
        {
            service: 'gmail',
            auth:{
                user: 'abhikhya.ashi@gmail.com',
                pass: 'ashi@3666'
            }
        }
    );
console.log(res);
    var mailOptions = {
        from: req.body.email, // sender address
        to: 'morphosyscorp@gmail.com',
        cc: 'abhikhya.ashi@gmail.com',
        // cc: 'morphosyscorp@gmail.com',
        subject: `Message from ${req.body.email}`,
        html: `<p>Name: ${req.body.username}</p><p>Email : ${req.body.email}</p><p>Subject: ${req.body.subject}</p><p>Message : ${req.body.message}`,
        context:{
            name: "Adebola", // replace {{name}} with Adebola
            company: 'My Company' // replace {{company}} with My Company
        }
    };

    transporter.sendMail(mailOptions, function(error, info){
        if(error){
            return console.log(error);
        }
        console.log('Message sent: ' + info.response);
        
    });
})
app.listen(3000, ()=>{
    console.log('server running');
});
